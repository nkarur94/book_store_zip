package com.bookstore.user.entity;

import java.time.LocalDate;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bookstore.user.DTO.UserRegistrationDTO;

import lombok.Data;

import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@Entity
@Table(name="user_details")
public class UserEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Long id;
	
	private String firstName;
	
	private String lastName;
	
	private int otp;
	
	private LocalDate dOB;
	
	private LocalDate registerDate;
	
	private LocalDate updateDate;
	
	private String password;
	
	
	private String eMail;
	
	private boolean verify;
	
	private LocalDate purchaseDate;
	
	private LocalDate expiryDate;

	public UserEntity( UserRegistrationDTO regisDTO) {
		this.firstName = regisDTO.firstName;
		this.lastName = regisDTO.lastName;
		this.dOB = regisDTO.dOB;
		this.otp = regisDTO.otp;
		this.registerDate = regisDTO.registerDate;
		this.updateDate=regisDTO.updateDate;
		this.password=regisDTO.password;
		this.eMail=regisDTO.eMail;
		this.verify=regisDTO.verify;
		this.purchaseDate=regisDTO.purchaseDate;
		this.expiryDate=regisDTO.expiryDate;

	}

}
