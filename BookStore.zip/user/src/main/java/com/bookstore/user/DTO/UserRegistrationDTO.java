package com.bookstore.user.DTO;

import java.time.LocalDate;

import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class UserRegistrationDTO {
	
	@Pattern(regexp = "^[A-Z]{1}[a-zA-Z\\s]{2,}$", message = "user firstname is invalid")
	public String firstName;
	
	@Pattern(regexp = "^[A-Z]{1}[a-zA-Z\\s]{2,}$", message = "user lastname is invalid")
	public String lastName;
	
	@NotNull
	public int otp;
	
	@JsonFormat(pattern="dd MM yyyy")
	@PastOrPresent(message ="invalid date of birth")
	public LocalDate dOB;
	
	@JsonFormat(pattern="dd MM yyyy")
	public LocalDate registerDate;
	
	@JsonFormat(pattern="dd MM yyyy")
	public LocalDate updateDate;
	
	//@Pattern(regexp = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$)", message = "WEEK PASSWORD ,use comibination of alphabets number and special charcters")
	public String password;

	@Pattern(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$",message = "invalid email address")
	public String eMail;
	
	
	public boolean verify;
	
	@JsonFormat(pattern="dd MM yyyy")
	public LocalDate purchaseDate;
	
	@JsonFormat(pattern="dd MM yyyy")
	@FutureOrPresent(message = "invalid expiry date")
	public LocalDate expiryDate;

}
