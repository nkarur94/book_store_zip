package com.bookstore.user.service;

import java.util.List;

import com.bookstore.user.DTO.ResponseDTO;
import com.bookstore.user.DTO.UserRegistrationDTO;
import com.bookstore.user.entity.UserEntity;

public interface IUserService {

	
	public ResponseDTO registerUserS(UserRegistrationDTO registerDTO);
	public ResponseDTO updateUserById(String token, UserRegistrationDTO registrationDTO);
	public List<UserEntity>  readUser();
	public ResponseDTO deleteById(String token );
	public ResponseDTO verifyUser(String token);
	public ResponseDTO getById(String token);
	public ResponseDTO login(String eMail, String password) ;
	public ResponseDTO viewVerifiedUserOnly();
	public ResponseDTO resetUserPassword(String token, String newPwd);
	public ResponseDTO otpVerification(String token, int otp);
	public ResponseDTO sendOptViaEMail(String token);
	public ResponseDTO forgetPasswordUser(String token, String newPwd);
	public boolean verifyUserForExternalUse(String token);
	public Long decodingForId(String token);
	
}
