package com.bookstore.user.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookstore.user.DTO.ResponseDTO;
import com.bookstore.user.DTO.UserRegistrationDTO;
import com.bookstore.user.entity.UserEntity;
import com.bookstore.user.exception.UserCustomException;
import com.bookstore.user.repository.UserRepo;
import com.bookstore.user.util.TokenUtil;

@Service
public class UserService implements IUserService {

	@Autowired
	UserRepo userRepoInService;

	@Autowired
	TokenUtil tokenUtil;
	
	@Autowired
	EMailService eMailService;
	

	@Override
	public ResponseDTO registerUserS(UserRegistrationDTO registerDTO) {
		
		UserEntity entity = new UserEntity(registerDTO);
		userRepoInService.save(entity);
		String tokenNo = tokenUtil.createToken(entity.getId());
		
	
		String link = eMailService.getLink("http://localhost:8081/user/verify/", entity.getId());

		
		eMailService.send("nkdaaku94@gmail.com", "verification", link );
		
		ResponseDTO response = new ResponseDTO("created user", entity, tokenNo);
		return response;
	}

	@Override
	public ResponseDTO updateUserById(String token, UserRegistrationDTO registrationDTO) {

		Long id = tokenUtil.decodeToken(token); //decodes the token and return id of type long
		UserEntity value = userRepoInService.findById(id).orElseThrow(() -> new UserCustomException("id not found")); // return exception if id not found
		UserEntity entity = new UserEntity(registrationDTO); 
		entity.setId(id);
		
		if (value.isVerify()) {  // checks if the given id is verified or not
			entity.setVerify(true);
			userRepoInService.save(entity);
			ResponseDTO response = new ResponseDTO("created user", entity);
			return response;
			
		}else {
			
			throw new UserCustomException("user not verified");
			
			}
		}
		
		

	@Override
	public List<UserEntity> readUser() {
		

		return userRepoInService.findAll();
	}

	@Override
	public ResponseDTO deleteById(String token) {
		Long id = tokenUtil.decodeToken(token);
		UserEntity user = userRepoInService.findById(id)
				.orElseThrow(() -> new UserCustomException("id not found"));
		if (user.isVerify() == true) {
			userRepoInService.deleteById(id);
			ResponseDTO response = new ResponseDTO("deleted id:" + id);
			return response;
		} else {
			throw new UserCustomException("user not verified");
		}

	}

	@Override
	public ResponseDTO verifyUser(String token) {

		Long id = tokenUtil.decodeToken(token);
		// System.out.println(id);
		UserEntity entity = userRepoInService.findById(id)
				.orElseThrow(() -> new UserCustomException("id not found"));
		entity.setVerify(true);
		userRepoInService.save(entity);
		ResponseDTO response = new ResponseDTO("verified user of id:" + id, entity);
		return response;

	}

	@Override
	public ResponseDTO getById(String token) {
		
		Long id = tokenUtil.decodeToken(token);
		
		UserEntity user = userRepoInService.findById(id).orElseThrow(() -> new UserCustomException("id not found"));
		
		if (user.isVerify() == true) {
			ResponseDTO response = new ResponseDTO("view by id:" + id , user);
			return response;
		} else {
		
			throw new UserCustomException("verified user not found");
			
		}
		
	}

	@Override
	public ResponseDTO login(String eMail, String password) {
		
		//userRepoInService.findByEMail(eMail).isEmpty();
		UserEntity entity = userRepoInService.findByEMail(eMail);
		if(entity == null) {
			throw new UserCustomException("email or password id not found");
		}else if (entity.isVerify()) {
				
			if (entity.getPassword().equals(password)) {
				ResponseDTO response = new ResponseDTO ("login succcess");
				return response;
				}
			else {
				throw new UserCustomException("password or email id not match");
			}
			
		}
		else {
		
			throw new UserCustomException("user is not verified");
		}
	}

	@Override
	public ResponseDTO viewVerifiedUserOnly() {
		// TODO Auto-generated method stub
		List<UserEntity> listOfUsers = userRepoInService.listOfUsers();
		
		if(listOfUsers.isEmpty()) {
			throw new  UserCustomException("no verified users in database");
		}else {
			ResponseDTO response = new ResponseDTO("only the verified users",listOfUsers);
			return response;

		}
		
		
	}

	@Override
	public ResponseDTO resetUserPassword(String token, String newPwd) {
		// TODO Auto-generated method stub
		Long id = tokenUtil.decodeToken(token);
		UserEntity entity = userRepoInService.findById(id)
				.orElseThrow(() -> new UserCustomException("id not found"));
		if(entity.isVerify()) {
			
			entity.setPassword(newPwd);
			userRepoInService.save(entity);
			ResponseDTO response = new ResponseDTO("password changed successfully");
			return response;
			}else {
				
				throw new  UserCustomException("users  is not verified to change the password");

			}
		
		
	}

	@Override
	public ResponseDTO otpVerification(String token, int otp) {
		// TODO Auto-generated method stub
		Long id = tokenUtil.decodeToken(token);
		UserEntity entity = userRepoInService.findById(id).orElseThrow(() -> new UserCustomException("id not found"));
		
		if(entity.getOtp() == otp) {
			ResponseDTO response = new ResponseDTO("opt matched, user verified");
			return response;
		}else {
			throw new  UserCustomException("opt not matched please enter valid opt number");
 
		}
		
	}

	@Override
	public ResponseDTO sendOptViaEMail(String token) {
		// TODO Auto-generated method stub
		Long id = tokenUtil.decodeToken(token);
		UserEntity entity = userRepoInService.findById(id).orElseThrow(() -> new UserCustomException("id not found"));
		
		if (entity.isVerify()) {
			Random r1 = new Random();   // using random class object to get the random no for otp
			int generatedOtp = r1.nextInt(999999); // generating otp of 6 digits using nextInt function in random class  
			entity.setOtp(generatedOtp);    // saving  the generated otp in to the entity object
			userRepoInService.save(entity);   // saving the changes made to the entity object in database;
			
			String link = eMailService.getLink("http://localhost:8081/user/otpverify/",entity.getId());
			
			eMailService.send(entity.getEMail(),"otp verification","the opt generted for verification is:"+ generatedOtp+" -----> link to verify "+ link+"/"+generatedOtp);
			ResponseDTO response = new ResponseDTO("OTP generated  and send to the user");
			return response;
		}
		else {
			throw new  UserCustomException("OTP is generated only for the verified user!!");

		}
		
	}

	@Override
	public ResponseDTO forgetPasswordUser(String token, String newPwd) {
		// TODO Auto-generated method stub
		Long id = tokenUtil.decodeToken(token);
		UserEntity entity = userRepoInService.findById(id).orElseThrow(() -> new UserCustomException("id not found"));
		
		if (entity.isVerify()) {
			
		
			String link = eMailService.getLink("http://localhost:8081/user/resetpwd/",entity.getId()); 
			eMailService.send(entity.getEMail(), "forget password", "RESET YOUR PASSWORD--> "+link+"/"+newPwd); // sends the mail to the user's email id
			
			entity.setPassword(newPwd);
			userRepoInService.save(entity);
			
			ResponseDTO response = new ResponseDTO("email has been sent to reset the paswword ");
			return response;
		}
		throw new  UserCustomException("verified user only!!");
	}

	@Override
	public boolean verifyUserForExternalUse(String token) {
		// TODO Auto-generated method stub
		Long id = tokenUtil.decodeToken(token);
		UserEntity entity = userRepoInService.findById(id).orElseThrow(() -> new UserCustomException("id not found"));
		if (entity.isVerify()) {
			return true;
		}else {
		return false;
		}
	}

	@Override
	public Long decodingForId(String token) {
		// TODO Auto-generated method stub
		Long id = tokenUtil.decodeToken(token);
		if (userRepoInService.findById(id).isPresent()) {
			return id;
			}else {
				return id =null;
			}
	}
	
	

}

	
	
	
	
	
	
	
	