package com.bookstore.user.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.user.DTO.ResponseDTO;
import com.bookstore.user.DTO.UserRegistrationDTO;
import com.bookstore.user.entity.UserEntity;
import com.bookstore.user.service.IUserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	IUserService iuserservice;
	
	@PostMapping("/add")  // this API help in adding the user details to the DB
	public ResponseEntity<ResponseDTO> registerUser(@Valid @RequestBody UserRegistrationDTO registerDTO){
		
		ResponseDTO response = iuserservice.registerUserS(registerDTO);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
		
	}

	@PutMapping("/update") //this API help in updating the excisting data in DB
	public ResponseEntity<ResponseDTO> updateUser(@RequestHeader String token,@Valid @RequestBody UserRegistrationDTO registrationDTO){
		ResponseDTO response = iuserservice.updateUserById(token, registrationDTO);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
		
	}
	@GetMapping("/view")  //help in looking into all user added in DB 
	public ResponseEntity<ResponseDTO> viewUser(){
		List<UserEntity> listUser = iuserservice.readUser();
		ResponseDTO response = new ResponseDTO("view all user",listUser);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
		
	}
	
	@GetMapping("/viewbyid")  // used to return the details of perticular user id it decodes token to get user id
	public ResponseEntity<ResponseDTO> viewUserBy(@RequestHeader String token){
		
		ResponseDTO response = iuserservice.getById(token);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
		
	}
	
	
	@DeleteMapping("/delete")  // deletes the user data from DB it takes Token as a parameter to delete the particular user 
	public ResponseEntity<ResponseDTO> deleteUser(@RequestHeader String token){
		
		ResponseDTO response = iuserservice.deleteById(token);
		
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	@GetMapping("/verify/{token}")  //it helps to verify or set the verify value to true for the given user
	public ResponseEntity<ResponseDTO> verifyUser(@PathVariable String token){
		ResponseDTO response = iuserservice.verifyUser(token);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	@GetMapping("/login")  // login with emailid and password that is been given in data base
	public ResponseEntity<ResponseDTO> loginUser (@RequestParam (value="usr") String eMail, @RequestParam (value="pwd") String password){
		ResponseDTO response = iuserservice.login(eMail, password);
		return new ResponseEntity<ResponseDTO>(response , HttpStatus.OK);
	}
	  
	@GetMapping("/resetpwd/{token}/{newPwd}")  // helps in resetting the particular users password
	public ResponseEntity<ResponseDTO> resetPassword(@PathVariable String token, @PathVariable String newPwd){
		ResponseDTO response = iuserservice.resetUserPassword(token, newPwd);
		return new ResponseEntity<ResponseDTO>(response,HttpStatus.OK);
	}
	
	
	@GetMapping("/getverifieduser")  //helps in finding all the user's who are verified 
	public ResponseEntity<ResponseDTO> viewVerified(){
		ResponseDTO response = iuserservice.viewVerifiedUserOnly();
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	@GetMapping ("/otpverify/{token}/{otp}")   // this API call helps in verifying the otp given is right or not 
	public ResponseEntity<ResponseDTO> verifyOtp( @PathVariable String token, @PathVariable (value="otp") int otp){
		ResponseDTO response = iuserservice.otpVerification(token, otp);
		return new ResponseEntity<ResponseDTO>(response,HttpStatus.OK);
	}
	
	@PostMapping("/sendotp")  // this call will eventually send the email to the user's emailid in DB with the generated Otp 
	public ResponseEntity<ResponseDTO> sendOtpNo(@RequestHeader String token){
		ResponseDTO response = iuserservice.sendOptViaEMail(token);
		return new ResponseEntity<ResponseDTO>(response,HttpStatus.OK);
	}
	
	@PostMapping("/forgetpwd/{newPwd}")
	public ResponseEntity<ResponseDTO> forgetPassword(@RequestHeader String token, @PathVariable String newPwd){
		ResponseDTO response = iuserservice.forgetPasswordUser(token, newPwd);
		
		return new ResponseEntity<ResponseDTO>(response,HttpStatus.OK);
	}
	
	@GetMapping("/verifiedtoken/{token}")  // used for rest template for verifing the user 
	public boolean verifyToken(@PathVariable String token) {
		boolean value = iuserservice.verifyUserForExternalUse(token);
		return value;
	}
	
	@GetMapping("/decodeForId/{token}")
	public Long decoding(@PathVariable String token) {
	Long userId = iuserservice.decodingForId(token);	
	return userId;
	}



}

	
