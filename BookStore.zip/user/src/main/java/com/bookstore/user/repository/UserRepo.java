package com.bookstore.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bookstore.user.entity.UserEntity;

public interface UserRepo extends JpaRepository<UserEntity, Long> {
	@Query(value="select * from user_details where e_mail = :eMail", nativeQuery=true)
	UserEntity findByEMail(String eMail);
	
	@Query(value="select * from user_details where verify=true",nativeQuery = true)
	List<UserEntity> listOfUsers();
	
}
