package com.bookstore.order.DTO;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor

public class ResponseDTO {
	
	public String message;
	public Object data;
	
	public ResponseDTO(String message) {
		super();
		this.message = message;
	}

}
