package com.bookstore.order.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.order.DTO.OrderDetailsDTO;
import com.bookstore.order.DTO.ResponseDTO;
import com.bookstore.order.service.IOrderService;

@RestController
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	IOrderService iOrder;
	
	@PostMapping("/placeorder")
	public ResponseEntity<ResponseDTO> orderPlace(@RequestHeader String token,	@Valid @RequestBody OrderDetailsDTO detailsDTO){
		ResponseDTO response = iOrder.placeOrder(token, detailsDTO);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	@PutMapping("/cancelorder/{orderId}")
	public ResponseEntity<ResponseDTO> orderCancel(@PathVariable Long orderId){
		ResponseDTO response = iOrder.cancelorder(orderId);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}

	@GetMapping("/getallorder")
	public ResponseEntity<ResponseDTO> orderGet(){
		ResponseDTO response = iOrder.getAllOrderNotCancelled();
		
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	@GetMapping("/getallorderbyid")
	public ResponseEntity<ResponseDTO> orderGetById(@RequestHeader String token){
		
		ResponseDTO responseDTO = iOrder.getOrderById(token);
		return new ResponseEntity<ResponseDTO>(responseDTO, HttpStatus.OK);
	}
	
	
}
