package com.bookstore.order.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bookstore.order.DTO.OrderDetailsDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@Table(name="order_list")
public class OrderDetailsEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long orderId;
	
	
	private LocalDate orderDate;
	
	private Long price;
	private int quantity;
	private String address;
	private Long userId;
	private Long bookId;
	private boolean cancel;
	
	
	public OrderDetailsEntity(OrderDetailsDTO detailsDTO) {
		this.orderDate=detailsDTO.orderDate;
		this.price=detailsDTO.price;
		this.quantity=detailsDTO.quantity;
		this.address=detailsDTO.address;
		this.bookId=detailsDTO.bookId;
		this.cancel=detailsDTO.cancel;
	}

}
