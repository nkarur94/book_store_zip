package com.bookstore.order.exception;

public class OrderCustomException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrderCustomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
