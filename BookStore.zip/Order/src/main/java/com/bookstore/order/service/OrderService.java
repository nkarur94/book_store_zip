package com.bookstore.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bookstore.order.DTO.OrderDetailsDTO;
import com.bookstore.order.DTO.ResponseDTO;
import com.bookstore.order.entity.OrderDetailsEntity;
import com.bookstore.order.exception.OrderCustomException;
import com.bookstore.order.repository.OrderRepo;

@Service
public class OrderService implements IOrderService {

	@Autowired
	OrderRepo orderRepInService;
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public ResponseDTO placeOrder( String token, OrderDetailsDTO detailsDTO) {
		// TODO Auto-generated method stub
		OrderDetailsEntity entity = new OrderDetailsEntity(detailsDTO);
		
		String url = "http://localhost:8081/user/decodeForId/"+token;  //used in decoding id in user project
		Long id = restTemplate.getForObject(url,Long.class);    //rest template helps in achieving the connection between different port 
		
		if(id==null) {
			throw new OrderCustomException("id not found");

		}else {
			entity.setUserId(id);  //setting the userid from user project to order project on decoding the token
			
			orderRepInService.save(entity);
			ResponseDTO response = new ResponseDTO("placed order successfully", entity);
			return response;
		}
		
	}

	@Override
	public ResponseDTO cancelorder(Long orderId) {
		// TODO Auto-generated method stub
		OrderDetailsEntity entity = orderRepInService.findById(orderId).orElseThrow(() -> new OrderCustomException("id not found"));
		entity.setCancel(true);
		orderRepInService.save(entity);
		ResponseDTO response = new ResponseDTO("cancelled successfully");
		return response;
	}

	@Override
	public ResponseDTO getAllOrderNotCancelled() {
		// TODO Auto-generated method stub
		List<OrderDetailsEntity> entity = orderRepInService.getNonCancelledOrderDetails();
		if (entity.isEmpty()) {
				throw new OrderCustomException("no active orders");
		} else 
			{
			ResponseDTO response = new ResponseDTO("list of order which in non cancelled status", entity);
			return response;
		}
	}

	@Override
	public ResponseDTO getOrderById(String token) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8081/user/decodeForId/"+token;  //used in decoding id in user project
		Long id = restTemplate.getForObject(url,Long.class);    //rest template helps in achieving the connection between different port 
		if(id==null) {
			throw new OrderCustomException("id not found");

		}else {
			
			List<OrderDetailsEntity> entity = orderRepInService.getorderById(id);
			if (entity.isEmpty()) {
				throw new OrderCustomException("no active orders for id:"+id);
				}
			else {
				
				//entity= orderRepInService.getNonCancelledOrderDetails();
				ResponseDTO response = new ResponseDTO("order plalaced by user:", entity);
				return response;
			}
		}
		
		
	}

}
