package com.bookstore.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bookstore.order.entity.OrderDetailsEntity;

public interface OrderRepo extends JpaRepository<OrderDetailsEntity, Long> {
	@Query(value="select * from order_list where cancel=false",nativeQuery = true)
	List <OrderDetailsEntity> getNonCancelledOrderDetails();
	
	@Query(value="select * from order_list where user_id= :userId",nativeQuery = true)
	List<OrderDetailsEntity> getorderById(Long userId);

}
