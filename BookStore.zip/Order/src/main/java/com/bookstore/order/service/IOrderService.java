package com.bookstore.order.service;


import com.bookstore.order.DTO.OrderDetailsDTO;
import com.bookstore.order.DTO.ResponseDTO;

public interface IOrderService {

	public ResponseDTO placeOrder(String token, OrderDetailsDTO detailsDTO);
	public ResponseDTO cancelorder(Long orderId);
	public ResponseDTO getAllOrderNotCancelled();
	public ResponseDTO getOrderById(String token);
}
