package com.bookstore.order.exception;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;

import com.bookstore.order.DTO.ResponseDTO;


@ControllerAdvice
public class OrderExceptionHandler {

	@ExceptionHandler(MethodArgumentNotValidException.class)
		public ResponseEntity<ResponseDTO> handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
			List<ObjectError> errorList = exception.getBindingResult().getAllErrors();
			List<String> errorMessage = errorList.stream().map(objerr -> objerr.getDefaultMessage())
					.collect(Collectors.toList());
			ResponseDTO responseDTO = new ResponseDTO("Exception while processing REST request", errorMessage);
			return new ResponseEntity<ResponseDTO>(responseDTO, HttpStatus.BAD_REQUEST);
		}
		
	@ExceptionHandler(OrderCustomException.class)
	public ResponseEntity<ResponseDTO> handleCustomException(OrderCustomException exception){
		ResponseDTO response = new ResponseDTO("ERROR while running API", exception.getMessage());
		return new ResponseEntity<ResponseDTO>(response,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(HttpClientErrorException.class)
	public ResponseEntity<ResponseDTO> handleHttpClientErrorException(HttpClientErrorException exception){
		ResponseDTO response = new ResponseDTO ("client side error", exception.getMessage());
		return new  ResponseEntity<ResponseDTO>(response,HttpStatus.NOT_FOUND);
		
	}
	
	
	
	
}
