package com.bookstore.order.DTO;

import java.time.LocalDate;


import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class OrderDetailsDTO {
	
	@JsonFormat(pattern="dd MM yyyy")
	public LocalDate orderDate;
	
	@NotNull(message="price cannot be null")
	public Long price;
	
	@NotNull (message="quantity cannot be blank")
	public int quantity;
	
	public String address;
	
	
	@NotNull(message="book id cannot be empty")
	public Long bookId;
	
	public boolean cancel;
	
	

}
