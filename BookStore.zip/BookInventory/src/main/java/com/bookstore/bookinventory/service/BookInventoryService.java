package com.bookstore.bookinventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bookstore.bookinventory.DTO.BookInventoryDTO;
import com.bookstore.bookinventory.DTO.ResponseDTO;
import com.bookstore.bookinventory.entity.BookInventoryEntity;
import com.bookstore.bookinventory.exception.BookInventoryCustomException;
import com.bookstore.bookinventory.repository.BookInventoryRepo;

@Service
public class BookInventoryService implements IBookInventoryService {

	@Autowired
	BookInventoryRepo repoInService;

	@Autowired
	private RestTemplate restTemplate; //creating the instance of resttemplate class 

	@Override
	public ResponseDTO addingbook(String token, BookInventoryDTO inventoryDTO) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8081/user/verifiedtoken/" + token; // API address for verifying the token
																			// generated to user return type boolean
		boolean verifyToken = restTemplate.getForObject(url, Boolean.class); // using rest template class object to
																				// redirect the call to give url

		if (verifyToken == true) { // only adds new data if the user if verified
			BookInventoryEntity entity = new BookInventoryEntity(inventoryDTO);
			repoInService.save(entity);
			ResponseDTO response = new ResponseDTO("added to inventory", entity);
			return response;
		} else {
			throw new BookInventoryCustomException("user id not verified"); // if the user is not verified it would
																			// throw custom exception with the message

		}

	}

	@Override
	public ResponseDTO updatingQuantity(String token, Long bookId, int quantity) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8081/user/verifiedtoken/" + token;
		boolean verifyToken = restTemplate.getForObject(url, Boolean.class);

		if (verifyToken == true) {
			BookInventoryEntity entity = repoInService.findById(bookId)
					.orElseThrow(() -> new BookInventoryCustomException("id your are searching is not found"));
			entity.setQuantity(quantity);
			repoInService.save(entity);
			ResponseDTO response = new ResponseDTO("quantity updated successfully", entity);
			return response;
		} else {
			throw new BookInventoryCustomException("user id not verified");

		}

	}

	@Override
	public ResponseDTO updatePrice(String token, Long bookId, Long price) { // method to update the price in DB only by
																			// verified user
		// TODO Auto-generated method stub
		String url = "http://localhost:8081/user/verifiedtoken/" + token; // API address for verifying the token
																			// generated to user
		boolean verifyToken = restTemplate.getForObject(url, Boolean.class); // using rest template class object to
																				// redirect the call to give url

		if (verifyToken == true) { // if the token or user id is verified then only it would update the changes

			BookInventoryEntity entity = repoInService.findById(bookId)
					.orElseThrow(() -> new BookInventoryCustomException("id  your searching is not found"));
			entity.setPrice(price); // saving the price variable value in entity object of user entity type
			repoInService.save(entity); // saving the changes made in the entity object into the DB
			ResponseDTO response = new ResponseDTO("price updated successfully", entity); // setting up the return type
																							// as response dto class
																							// with the message and data
																							// parameters
			return response; // returning the responseDTO type object to the method

		} else {
			throw new BookInventoryCustomException("user id not verified"); // if the user is not verified it would
																			// throw custom exception with the message

		}

	}

	@Override
	public List<BookInventoryEntity> viewBookInventory() {

		List<BookInventoryEntity> inventory = repoInService.findAll();
		// TODO Auto-generated method stub
		return inventory;
	}

	@Override
	public ResponseDTO deleteBookInInventory(String token, Long bookId) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8081/user/verifiedtoken/" + token; // API address for verifying the token
																			// generated to user return type boolean
		boolean verifyToken = restTemplate.getForObject(url, Boolean.class); // using rest template class object to
																				// redirect the call to give url

		repoInService.findById(bookId)
				.orElseThrow(() -> new BookInventoryCustomException("id  your searching is not found"));
		if (verifyToken == true) {
			repoInService.deleteById(bookId); // deleting the particular book id details
			ResponseDTO response = new ResponseDTO("deleted book of id:" + bookId + " successfully");
			return response;
		} else {
			throw new BookInventoryCustomException("only verified user can delete the items");
		}

	}

	@Override
	public ResponseDTO sortBookBypriceToHighToLow() {
		// TODO Auto-generated method stub
		List<BookInventoryEntity> entity = repoInService.sortByHighToLow();
		ResponseDTO response = new ResponseDTO("sorted to high to low", entity);
		return response;
	}

	@Override
	public ResponseDTO sortBookBypriceToLowToHigh() {
		// TODO Auto-generated method stub
		List<BookInventoryEntity> entity = repoInService.sortByLowToHigh();
		ResponseDTO response = new ResponseDTO("sorted to high to low", entity);
		return response;

	}

	@Override
	public List<BookInventoryEntity> searchByName(String bookName) {
		// TODO Auto-generated method stub
		List<BookInventoryEntity> entity = repoInService.findByBookNameStartsWith(bookName);
		if (entity.isEmpty()) {
			throw new BookInventoryCustomException("book name you are searching  for is not found!!");
		} else {
			return entity;
		}
	}

	@Override
	public int getQuantityForBook(Long bookId) {
		// TODO Auto-generated method stub
		if(repoInService.findById(bookId).isPresent()) {
			
			Optional <BookInventoryEntity> entity = repoInService.findById(bookId);
			System.out.println(entity);
			int quantity = entity.get().getQuantity();
			return quantity;
		}
		else {
			return 0;  //this means there is no such book id  
		}
	}

}
