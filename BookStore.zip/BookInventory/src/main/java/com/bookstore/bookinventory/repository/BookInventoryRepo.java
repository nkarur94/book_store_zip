package com.bookstore.bookinventory.repository;

import java.util.List;

import org.hibernate.type.TrueFalseType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bookstore.bookinventory.entity.BookInventoryEntity;

public interface BookInventoryRepo extends JpaRepository<BookInventoryEntity, Long> {
	
	@Query(value="select * from book_inventory order by price desc",nativeQuery = true)
	public List<BookInventoryEntity> sortByHighToLow();
	
	@Query(value="select * from book_inventory order by price",nativeQuery = true)
	public List<BookInventoryEntity> sortByLowToHigh();
	
	public List<BookInventoryEntity> findByBookNameStartsWith(String bookName);

}
