package com.bookstore.bookinventory.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.bookinventory.DTO.BookInventoryDTO;
import com.bookstore.bookinventory.DTO.ResponseDTO;
import com.bookstore.bookinventory.entity.BookInventoryEntity;
import com.bookstore.bookinventory.service.IBookInventoryService;

@RestController
@RequestMapping("/bookinventory")
public class BookInventoryController {
	
	@Autowired             // used to create the instance of IBookInventoryService class
	IBookInventoryService iInventoryInService;   
	
	@PostMapping("/add")
	public ResponseEntity<ResponseDTO> adding(@RequestHeader String token, @Valid @RequestBody BookInventoryDTO inventoryDTO){
		
		ResponseDTO response = iInventoryInService.addingbook(token, inventoryDTO);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}

	@PutMapping("/changequantity/{bookId}")
	public ResponseEntity<ResponseDTO> updateQuantity(@RequestHeader String token, @PathVariable Long bookId, @RequestParam (value = "qnty") int quantity){
		ResponseDTO response = iInventoryInService.updatingQuantity( token,bookId, quantity);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
				
		
	}
	
	@PutMapping ("/changeprice/{bookId}")
	public ResponseEntity<ResponseDTO> updatePrice(@RequestHeader String token, @PathVariable Long bookId, @RequestParam (value="price") Long price){
		ResponseDTO response = iInventoryInService.updatePrice(token,bookId, price);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
				
		}
	
	@GetMapping("/view")
	public ResponseEntity<ResponseDTO> viewBooks(){
		List<BookInventoryEntity> inventory = iInventoryInService.viewBookInventory();
		ResponseDTO response = new ResponseDTO("book in inventory",inventory);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	
	@DeleteMapping("/delete/{bookId}")
	public ResponseEntity<ResponseDTO> deleteBook(@RequestHeader String token, @PathVariable Long bookId){
		ResponseDTO response= iInventoryInService.deleteBookInInventory(token,bookId);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	
	@GetMapping("/sortbyhigh")
	public ResponseEntity<ResponseDTO> sortToHigh(){
		ResponseDTO response = iInventoryInService.sortBookBypriceToHighToLow();
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
		
	}
	@GetMapping("/sortbylow")
	public ResponseEntity<ResponseDTO> sortTolow(){
		ResponseDTO response = iInventoryInService.sortBookBypriceToLowToHigh();
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
		
		}
	
	@GetMapping("/search/{bookName}")
	public ResponseEntity<ResponseDTO> search(@PathVariable String bookName){
		List<BookInventoryEntity> entity = iInventoryInService.searchByName(bookName);
		ResponseDTO response = new ResponseDTO("search by name",entity);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
		
	}
	
	@GetMapping("/getquantity/{bookId}")
	public int getQuantity(@PathVariable Long bookId) {
		int quantityOfBook = iInventoryInService.getQuantityForBook(bookId);
		return quantityOfBook;
	}
	
}
