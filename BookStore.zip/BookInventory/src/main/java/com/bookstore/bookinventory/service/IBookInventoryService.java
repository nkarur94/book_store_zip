package com.bookstore.bookinventory.service;

import java.util.List;

import com.bookstore.bookinventory.DTO.BookInventoryDTO;
import com.bookstore.bookinventory.DTO.ResponseDTO;
import com.bookstore.bookinventory.entity.BookInventoryEntity;

public interface IBookInventoryService {

	public ResponseDTO addingbook(String token, BookInventoryDTO inventoryDTO);
	public ResponseDTO updatingQuantity(String token,Long bookId, int quantity);
	public ResponseDTO updatePrice(String token, Long bookId, Long price);
	public List<BookInventoryEntity> viewBookInventory();
	public ResponseDTO deleteBookInInventory(String token, Long bookId);
	public ResponseDTO sortBookBypriceToHighToLow();
	public ResponseDTO sortBookBypriceToLowToHigh();
	public List<BookInventoryEntity> searchByName(String BookName);
	public int getQuantityForBook(Long bookId);
}
