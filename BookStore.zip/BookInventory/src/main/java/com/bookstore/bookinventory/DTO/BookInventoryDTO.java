package com.bookstore.bookinventory.DTO;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Data;

@Data
public class BookInventoryDTO {  
	
	@Pattern(regexp = "^[A-Z]{1}[a-zA-Z\\s]{2,}$", message = "book name is invalid")
	public String bookName;
	
	@Pattern(regexp = "^[A-Z]{1}[a-zA-Z\\s]{2,}$", message = "author name is invalid")
	public String bookAuthor;
	
	public String bookDescription;
	
	@NotNull(message="price cannot be null value")
	public Long price;
	
	@NotNull (message="quantity cannot be empty")
	public int quantity;


}
