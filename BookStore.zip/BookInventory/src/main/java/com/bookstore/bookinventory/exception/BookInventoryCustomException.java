package com.bookstore.bookinventory.exception;

public class BookInventoryCustomException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookInventoryCustomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
