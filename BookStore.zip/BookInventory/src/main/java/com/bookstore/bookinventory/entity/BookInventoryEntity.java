package com.bookstore.bookinventory.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bookstore.bookinventory.DTO.BookInventoryDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@Table(name="book_inventory")
public class BookInventoryEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long bookId;
	
	private String bookName;
	private String bookAuthor;
	private String bookDescription;
	private Long price;
	private int quantity;
	
	public BookInventoryEntity(BookInventoryDTO bookDTO) {
		super();
		this.bookName=bookDTO.bookName;
		this.bookAuthor=bookDTO.bookAuthor;
		this.bookDescription=bookDTO.bookAuthor;
		this.price=bookDTO.price;
		this.quantity=bookDTO.quantity;
	}
	


}
