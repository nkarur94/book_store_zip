package com.bookstore.bookinventory.DTO;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@ToString
@NoArgsConstructor
public class ResponseDTO {
	
	public String message;
	public Object data;
	
	
	public ResponseDTO(String message) {
		super();
		this.message = message;
	}
	
	

}
