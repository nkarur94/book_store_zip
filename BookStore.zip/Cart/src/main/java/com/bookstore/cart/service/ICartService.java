package com.bookstore.cart.service;

import com.bookstore.cart.DTO.CartDetailsDTO;
import com.bookstore.cart.DTO.ResponseDTO;

public interface ICartService {
	
	public ResponseDTO addItemsTocart(String token, CartDetailsDTO detailsDTO);
	public ResponseDTO removeItemsFromCart(String token,Long cartId);
	public  ResponseDTO updateQuantityUsingcartId(String token, Long cartId, int quantity);
	public ResponseDTO viewCartItemsById(String token);
	public ResponseDTO viewAllCartDetails(String token);
	
	}

