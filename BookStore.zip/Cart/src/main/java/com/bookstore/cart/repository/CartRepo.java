package com.bookstore.cart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bookstore.cart.entity.CartEntity;

public interface CartRepo  extends JpaRepository<CartEntity, Long>{
	
	@Query(value="select * from cart_service where user_id= :userId",nativeQuery = true) //@query annotation allow you to write down the sql query to get the results
	public List<CartEntity> findCartById(Long userId); //this method uses the native query

}
