package com.bookstore.cart.exception;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;

import com.bookstore.cart.DTO.ResponseDTO;

@ControllerAdvice
public class CartExceptionHandler {
	
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ResponseDTO> handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
		List<ObjectError> errorList = exception.getBindingResult().getAllErrors();
		List<String> errorMessage = errorList.stream().map(objerr -> objerr.getDefaultMessage())
				.collect(Collectors.toList());
		ResponseDTO responseDTO = new ResponseDTO("Exception while processing REST request", errorMessage);
		return new ResponseEntity<ResponseDTO>(responseDTO, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CartCustomException.class)
	public ResponseEntity<ResponseDTO> handlingCustomException(CartCustomException execption) {
		ResponseDTO response = new ResponseDTO("exception while running Cart API", execption.getMessage());
		return new ResponseEntity<ResponseDTO>(response,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(HttpClientErrorException.class)
	public ResponseEntity<ResponseDTO> handleHttpClientErrorException(HttpClientErrorException exception){
		ResponseDTO response = new ResponseDTO ("client side error", exception.getMessage());
		return new  ResponseEntity<ResponseDTO>(response,HttpStatus.NOT_FOUND);
		
	}
	
	
}
