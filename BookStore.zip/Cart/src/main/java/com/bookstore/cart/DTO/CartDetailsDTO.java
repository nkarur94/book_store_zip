package com.bookstore.cart.DTO;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data   		//its a lomboak type annoation which creates setter getter tostring and contructor
public class CartDetailsDTO {
	
	
	
	@NotNull(message = "book id cannot be empty") //validating not be null 
	public Long bookId;
	
	@NotNull(message="quantity cannot be empty") //validating not be null 
	public int quantity;

}
