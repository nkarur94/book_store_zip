package com.bookstore.cart.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.bookstore.cart.DTO.CartDetailsDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data                       //its a lomboak type annoation which creates setter getter tostring and contructor 
@Entity 					// it tell this class is used as a table type the variables used in class r used in creating the table in DB
@Table(name="cart_service") // used to name the DB table name 
public class CartEntity {
	
	@Id   //this annotation will male the variable carId as primary key
	@GeneratedValue(strategy = GenerationType.AUTO) // this annoation will generate the automatic values which present in hibernate_sequence table
	private Long cartId;
	
	private Long userId;
	
	private Long bookId;
	
	
	private int quantity;
	 
	public CartEntity(CartDetailsDTO detailsDTO) {
		
		this.bookId=detailsDTO.bookId;
		this.quantity=detailsDTO.quantity;
	}

}
