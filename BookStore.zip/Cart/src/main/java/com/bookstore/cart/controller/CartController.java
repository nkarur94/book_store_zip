package com.bookstore.cart.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.cart.DTO.CartDetailsDTO;
import com.bookstore.cart.DTO.ResponseDTO;
import com.bookstore.cart.service.ICartService;

@RestController   //@RestController will make this class as controller 
@RequestMapping("/cart") //if /cart fired in port no this class is used
public class CartController {
	
	@Autowired					//this annotation help in creating the object in spring 
	ICartService iCartService;	//creation of object of ICartService class with the above annotation 
	
	
	//this method will add the items in cart, @PostMapping annotation help in calling this method when /add is fired at given port no
	@PostMapping("/add")
	public ResponseEntity<ResponseDTO> addItem(@RequestHeader String token, @Valid @RequestBody CartDetailsDTO detailsDTO){ //@RequestBody annotation is used so that we can use the varibles present in that class to pass the data
		ResponseDTO response = iCartService.addItemsTocart(token, detailsDTO);  //using interface type object to call the method which is implemented in service class
		return new ResponseEntity<ResponseDTO>(response,HttpStatus.OK); // this type of return we are using so that we cant pass the standard response back to the client with http status
		
	}
	
	@DeleteMapping("/remove/{cartId}")  
	public ResponseEntity<ResponseDTO> removeItem(@RequestHeader String token, @PathVariable Long cartId){ // @pathVariable annotation takes the values from the path
		ResponseDTO response = iCartService.removeItemsFromCart(token, cartId);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	@PutMapping("/update/{cartId}")
	public ResponseEntity<ResponseDTO> updateItem(@RequestHeader String token, @PathVariable Long cartId, @RequestParam (value="qnty") int quantity){
		ResponseDTO response = iCartService.updateQuantityUsingcartId(token, cartId, quantity);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}

	@GetMapping("/view")
	public ResponseEntity<ResponseDTO> viewById(@RequestHeader String token){
		ResponseDTO response = iCartService.viewCartItemsById(token);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	@GetMapping("/viewall")
	public ResponseEntity<ResponseDTO> viewAll (@RequestHeader String token){
		ResponseDTO response = iCartService.viewAllCartDetails(token);
		return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
	}
	
	
}
