package com.bookstore.cart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bookstore.cart.DTO.CartDetailsDTO;
import com.bookstore.cart.DTO.ResponseDTO;
import com.bookstore.cart.entity.CartEntity;
import com.bookstore.cart.exception.CartCustomException;
import com.bookstore.cart.repository.CartRepo;

@Service
public class CartService implements ICartService {

	@Autowired // this annotation help in creating the object
	CartRepo repoInService; // creation of object of CartRepo class with the above annotation

	@Autowired
	RestTemplate restTemplate;

//	addItemscart method is used to add the items to the cart into the database and this method overrides the method in interface class
	@Override
	public ResponseDTO addItemsTocart(String token, CartDetailsDTO detailsDTO) {
		// TODO Auto-generated method stub
		String urlForVerifying = "http://localhost:8081/user/verifiedtoken/" + token;
		boolean verify = restTemplate.getForObject(urlForVerifying, boolean.class);

		if (verify == false) {
			throw new CartCustomException("user not verified");
		} else {

			String urlForId = "http://localhost:8081/user/decodeForId/" + token;
			Long id = restTemplate.getForObject(urlForId, Long.class);

			if (id == null) {
				throw new CartCustomException("id not found");

			} else {

				CartEntity entity = new CartEntity(detailsDTO);

				String urlForBookStore = "http://localhost:8082/bookinventory/getquantity/" + entity.getBookId();
				int qntyOrId = restTemplate.getForObject(urlForBookStore, int.class); // gets the quantity along with
																						// book present or not

				if (qntyOrId == 0) { // this statement checks for book id present or not
					throw new CartCustomException("bookid is not available");

				}

				else {

					if (qntyOrId < entity.getQuantity()) {

						throw new CartCustomException("quantity is not available");

					} else {
						entity.setUserId(id);

						repoInService.save(entity); // saves the data present in object to DB

						ResponseDTO response = new ResponseDTO("items added to cart now", entity);
						return response;
					}

				}

			}

		}

	}

	@Override
	public ResponseDTO removeItemsFromCart(String token, Long cartId) {
		// TODO Auto-generated method stub
		String urlForVerifying = "http://localhost:8081/user/verifiedtoken/" + token;
		boolean verify = restTemplate.getForObject(urlForVerifying, boolean.class);

		if (verify == false) {
			throw new CartCustomException("user not verified");

		} else {

			if (repoInService.findById(cartId).isPresent()) { // checks for id in DB
				repoInService.deleteById(cartId); // deletes the cart by id
				ResponseDTO response = new ResponseDTO("deleted successfully");

				return response;

			} else {
				throw new CartCustomException("cart id not found"); // used custom execption to throw if the cart id was
																	// not
																	// found in DB
			}

		}

	}

	@Override
	public ResponseDTO updateQuantityUsingcartId(String token, Long cartId, int quantity) {
		// TODO Auto-generated method stub
		String urlForVerifying = "http://localhost:8081/user/verifiedtoken/" + token;
		boolean verify = restTemplate.getForObject(urlForVerifying, boolean.class);

		if (verify == false) {
			throw new CartCustomException("user not verified");

		} else {
			if (repoInService.findById(cartId).isPresent()) {
				CartEntity entity = repoInService.findById(cartId).orElseThrow();
				entity.setQuantity(quantity); // using entity object we are setting quantity to the user defined value
				repoInService.save(entity); // saving the changes made
				ResponseDTO response = new ResponseDTO("updated quantity");
				return response;
			} else {
				throw new CartCustomException("cannot find cart id while updating");
			}
		}

	}

	@Override
	public ResponseDTO viewCartItemsById(String token) {
		// TODO Auto-generated method stub
		String urlForVerifying = "http://localhost:8081/user/verifiedtoken/" + token;
		boolean verify = restTemplate.getForObject(urlForVerifying, boolean.class);

		if (verify == false) {
			throw new CartCustomException("user not verified");

		} else {
			String url = "http://localhost:8081/user/decodeForId/" + token;
			Long id = restTemplate.getForObject(url, Long.class);
			
			if (id == null) {
				throw new CartCustomException("id not found");

			} else {
				List<CartEntity> entity = repoInService.findCartById(id); // created the custom query to find the cart
																			// deatils by userid
				ResponseDTO response = new ResponseDTO("view by id", entity);
				return response;

			}
		}
		
		

	}

	@Override
	public ResponseDTO viewAllCartDetails(String token) {
		// TODO Auto-generated method stub
		String urlForVerifying = "http://localhost:8081/user/verifiedtoken/" + token;
		boolean verify = restTemplate.getForObject(urlForVerifying, boolean.class);

		if (verify == false) {
			throw new CartCustomException("user not verified");

		} else {
			
			List<CartEntity> entity = repoInService.findAll();
			if (entity.isEmpty()) {
				throw new CartCustomException("nothing to show");

			} else {
				ResponseDTO response = new ResponseDTO("All cart details", entity);
				return response;
			}

		}
	}
		

}
